// Names: Ryan Wolpert and Jules Prater
// COSC 302 Project 1
// Music library file manager

#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

/* Structs to store song, album, and artist information
 * Note: these are used from Dr. Emrich's lab writeup */
struct Song {
    string title;
    int duration;
    int trackNumber;
};

struct Album {
    string name;
    map<int, Song> songs;
    int totalSongs;
    int totalTime;
};

struct Artist {
    string name;
    map<string, Album> albums;
    int totalSongs;
    int totalTime;
};

/*Helper function to replace underscores with spaces. Uses functions from the
string library to replace the underscores with spaces.*/ 
void replaceUnderscores(string &str) {
    replace(str.begin(), str.end(), '_', ' ');
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        cerr << "Usage: " << argv[0] << " <file>" << endl;
        return 1;
    }

    ifstream file(argv[1]);
    if (!file) {
        cerr << "Error opening file: " << argv[1] << endl;
        return 1;
    }

    // Map to store the library
    map<string, Artist> library;
    string line;

    /* Read the file line by line. The metadata categories, which are separated by spaces, are
	 read into their respective variables. A new integer variable, trackNumber, is created to
	 keep count of the numbers on the track, The first thing done after reading in the lines of
	 text is replacing the underscores with spaces, to make sure the content of all the variables
	 is correct before sorting them. Afterwards, we calculated the duration of each song in seconds.
	 To ensure the semicolon was properly taken into account, we first initialized the variable as a
	 string rather than an int. We used the string-to-int function to find the colon, separate the
	 minutes from the seconds, convert it to an int, and set the total time to minutes * 60 + seconds.
	 */ 
    while (getline(file, line)) {
        istringstream iss(line);
        string title, time, artistName, albumName, genre;
        int trackNumber;

        // Parse each element from the line
        iss >> title >> time >> artistName >> albumName >> genre >> trackNumber;

        //Calls helper function
        replaceUnderscores(title);
        replaceUnderscores(artistName);
        replaceUnderscores(albumName);

        // Calculate the duration in seconds
        int minutes = stoi(time.substr(0, time.find(':'))); // find position of colon and extract substring
        int seconds = stoi(time.substr(time.find(':') + 1)); // extracts substring from position after colon to end of string
        int duration = minutes * 60 + seconds;

		/*A new instance of the object Song is created to hold each new song. The code checks to see
		  if the attached artist and a;bum are already in the library, and if not, the artist and/or
		  album are added. A constant reference is gotten to the artist to add the song to, and the
		  artist's songs and albums are updated.*/

        // Create a song object
        Song song = {title, duration, trackNumber};

        // If the artist is not in the library, add them
        if (library.find(artistName) == library.end()) {
            library[artistName] = Artist{artistName, map<string, Album>(), 0, 0};
        }

        // Get a reference to the artist
        Artist &artist = library[artistName];

        // Album logic works the same way as artist logic
        if (artist.albums.find(albumName) == artist.albums.end()) {
            artist.albums[albumName] = Album{albumName, map<int, Song>(), 0, 0};
        }

        Album &album = artist.albums[albumName];

        // Add the song to the album and artist
        album.songs[trackNumber] = song;
        album.totalSongs++;
        album.totalTime += duration;

        // Update the artist's total songs and time
        artist.totalSongs++;
        artist.totalTime += duration;
    }

	/*The artist strings are put into a vector to be sorted, where they're sorted alphabetically
	 and the vector is printed. The iterator is deferenced so an iterator is not returned. The 
	 same happens with each album as the code goes through each artist, and same with the songs
	 as the code goes through each album. Finally, standard input formats and prints the artists
	 with their albums, songs, and play times.*/

    // Transfer artists to a vector for sorting
    vector<Artist> sortedArtists;
    for (map<string, Artist>::iterator it = library.begin(); it != library.end(); it++) {
        sortedArtists.push_back(it->second);
    }

    // Sort the artists by name
    sort(sortedArtists.begin(), sortedArtists.end(), [](const Artist &a, const Artist &b) {
        return a.name < b.name;
    });

    // Print artists
    for (vector<Artist>::iterator it = sortedArtists.begin(); it != sortedArtists.end(); it++) {
        // Dereference the iterator and create a reference to the artist
        Artist &artist = *it; 

        cout << artist.name << ": " << artist.totalSongs << ", " << artist.totalTime / 60 << ":"
             << setw(2) << setfill('0') << artist.totalTime % 60 << endl;

        // Transfer albums to a vector for sorting - works the same as artist logic
        vector<Album> sortedAlbums;
        for (map<string, Album>::iterator it2 = artist.albums.begin(); it2 != artist.albums.end(); it2++) {
            sortedAlbums.push_back(it2->second);
        }

        // Sort the albums by name
        sort(sortedAlbums.begin(), sortedAlbums.end(), [](const Album &a, const Album &b) {
            return a.name < b.name;
        });

        // Print albums
        for (vector<Album>::iterator it2 = sortedAlbums.begin(); it2 != sortedAlbums.end(); it2++) {
            Album &album = *it2; // Dereference the iterator - works the same as above

            cout << "        " << album.name << ": " << album.totalSongs << ", " << album.totalTime / 60 << ":"
                 << setw(2) << setfill('0') << album.totalTime % 60 << endl;

            // Transfer, sort, print songs - works the same as past two sections
            vector<Song> sortedSongs;
            for (map<int, Song>::iterator it3 = album.songs.begin(); it3 != album.songs.end(); it3++) {
                sortedSongs.push_back(it3->second);
            }

            // Sort songs
            sort(sortedSongs.begin(), sortedSongs.end(), [](const Song &a, const Song &b) {
                return a.trackNumber < b.trackNumber;
            });

            //Custom iterators are used to sort through the sortedSongs m
            for (vector<Song>::iterator it3 = sortedSongs.begin(); it3 != sortedSongs.end(); it3++) {
                Song &song = *it3; // Dereference the iterator - works the same as above
                
                cout << "                " << song.trackNumber << ". " << song.title << ": " << song.duration / 60 << ":"
                     << setw(2) << setfill('0') << song.duration % 60 << endl;
            }
        }
    }
    return 0;
}
